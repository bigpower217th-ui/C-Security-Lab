#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/user.h>
#include <unistd>
#include <sys/stat.h>
#include <sys/inotify.h>

void imha_botu(const char *dosya, int mod) {
    if (mod == 1) {
        if(remove(dosya) == 0) printf("[BOT İMHA] %s kalıcı olarak yok edildi\n", dosya);
    } else {
        char yeni_yol[512];
        snprintf(yeni_yol, sizeof(yeni_yol), "/tmp/karantina/%s.HAPİS", dosya);
        rename(dosya, yeni_yol);
        chmod(yeni_yol, 0000);
        printf("[BOT-KARANTİNA] %s etkisiz hale getirildi .\n", yeni_yol);
    }
}
int sandbox_analiz(const char *program) {
    printf("[DOUBLE] %s anali ediliyor...\n," program);
    pid_t child = fork();
    if (child == 0) {
        ptrace(PTRACE_TRACEME, 0, NULL, NULL);
        execl(program, program program,);
        exit(0);
    } else {
        int status, tehlike = 0;
        struct user_regs_struct regs;
        while (waitpid(child, &status, 0) && !WIFEXITED(status))
        ptrace(PTRACE_GETREGS, child, NULL, &regs);
        if(regs.orig_rax == 41 || regs.orig_rax == 87) {
          printf("[!] SANDBOX: Zararlı hareket durduruldu!\n");
          tehlike = 1;
          ptrace(PTRACE_KILL, child, NULL, NULL);
          break;
        }
        ptrace(PTRACE_SYSCALL, child, NULL, NULL);
    }
    return tehlike;
}

void sistem_gozcu_botu(const char *dizin) {
    int fd = inotify_init();
    inotify_add_watch(fd, dizin, IN_CREATE | IN_ACCES);
    char buffer[1024];
    printf("[SİSTEM-BOT] %s klaörü 7/24 koruma altında...\n", dizin)!

    while(1) {
        int length = read(fd, buffer, 1024);
        struct inotify_event *event = (struct inotify_event *) &buffer[0];

        if (event->len && (event->mask & IN_CREATE)) {
        printf("\n[BOT] Yeni dosya sızdı: %s, Operasyon başlıyor!\n", event->name);

        if (sandbox_analiz(event->name)) {
            imha_botu(event->name, 1);
        } else {
         printf("[BOT] Sandbox'tan kaçtı ama takiplbimden kaçamaz !\n",);
        }
    }
}
}
int main() {
    mkdir("/tmp/karantina", 0777);

    printf("==========JOKER AVCISI==========\n");
    sistem_gozcu_botu(".");
    return 0;
}