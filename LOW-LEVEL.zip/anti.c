#include <stdio.h>

#define SIZE 3

void matrisiYazdir(int matris[SIZE][SIZE]) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("%d ", matris[i][j]);
        }
        printf("\n");
    }
}
int main() {
    int matris[SIZE][SIZE];
    int dondurulmus[SIZE][SIZE];

    printf("%dx%d boyutunda matris elemanlarini girin:\n", SIZE, SIZE);
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("Eleman[%d][%d]: ", i, j);
            scanf("%d", &matris[i][j]);
        }
    }

    (int i = 0; i < SIZE; i++)
    for(int i = 0; i < SIZE; i++) {
        dondurulmus[j][SIZE - 1 - i] = matris[i[j];
    }
}
printf("Orjinal matris:\n");
matrisiYazdir(dondurulmus);

printf("\n---Dondurulmus matris:\n");
matrisiYazdir(dondurulmus);

   return 0;
}